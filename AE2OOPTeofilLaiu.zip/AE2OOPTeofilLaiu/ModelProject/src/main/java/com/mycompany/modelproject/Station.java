
package com.mycompany.modelproject;

/**
 *
 * @author Teo
 */
public class Station {
    
     String stationname;
     int zone;
    boolean price;
    
    public Station(String name, int zone) {
        this.stationname = name;
        this.zone = zone;
        
    }    
    public String getStationName() {
        return stationname;
    }
    public int getZone() {
        return zone;
    }
    public void setStationName(String stationname) {
        this.stationname = stationname;
    }
    public void setZone(int zone) {
        this.zone = zone;
    }
    
   
    
    
    public String info() {
        return "Station " + getStationName() + " located in zone " + getZone() ;
    }
    public void printInfo() {
        System.out.println(info());
    }
    
}
