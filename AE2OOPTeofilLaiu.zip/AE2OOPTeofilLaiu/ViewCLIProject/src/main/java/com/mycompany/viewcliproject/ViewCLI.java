
package com.mycompany.viewcliproject;

import com.mycompany.controllerproject.Controller;

/**
 *
 * @author Teo
 */
public class ViewCLI {
    public static void main(String[] args) {
        System.out.println("This are the added Stations");
        
      
        Controller c = new Controller();
        
        c.add("Waterloo", 1);
        c.add("Mile End", 2);
        c.add("Stratford", 4);
        System.out.println("Number of Stations: " + c.getSize());

        var x = c.get(0);
        x.printInfo();

        
        System.out.println("Number of Stations: " + c.getSize());
        
        System.out.println("List of all Stations: ");
        c.printAll();
        
        System.out.println("Removing Mile End...");
        c.remove(1); //removes Mile End station as it is the second. the count starts from 0
        System.out.println("Listing remaining stations:");
        c.printAll();
    }    
    
}
