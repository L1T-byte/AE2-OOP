
package com.mycompany.viewwebproject;

import com.mycompany.controllerproject.Controller;

/**
 *
 * @author Teo
 */
public class ControllerFactory {
    
    private static Controller c;
    
    public static Controller getController(String objType) {
        if (objType.equals("Controller")) {
            if (ControllerFactory.c == null) {ControllerFactory.c = new Controller();}
            return ControllerFactory.c;
        }
        return null;
    }    
    
}
