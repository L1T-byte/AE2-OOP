
package com.mycompany.controllerproject;

import com.mycompany.modelproject.Station;
import java.util.ArrayList;

/**
 *
 * @author Teo
 */
public class Controller {
     ArrayList<Station> StationList;
    
    public Controller() {
        StationList = new ArrayList<Station>();
    }    
    public void add(String stationname, int zone) {
        
        StationList.add(new Station(stationname, zone));
    } 
    public int getSize() {
        return StationList.size();
    }    
    public Station get(int i) {
        return StationList.get(i);
    }
    public void remove(int i) {
        StationList.remove(i);
    }
    public int getIndex(Station a) {
        return StationList.indexOf(a);
    }
    public void printAll() {
        for (Station x : StationList) {
            x.printInfo();
        }
    }
    public String printHTML() {
        String output = "<table border='1'>";
        for (Station x : StationList) {
            String d = "<form action='' method='post'><input type='hidden' id='action' name='action' value='delete' /><input type='hidden' id='aid'    name='aid'    value='"+getIndex(x)+"' /><input type='submit' name='submit' value='Delete' /></form>";
        
            String u = "<form action='' method='get'><input type='submit' value='Update' /></form>";
            output = output + "<tr><td>"+x.getStationName()+"</td><td>"+x.getZone()+"</td><td>"+d+"</td><td>"+u+"</td></tr>";
        }
        return output + "</table>\n";
    }

   

   

    
}
